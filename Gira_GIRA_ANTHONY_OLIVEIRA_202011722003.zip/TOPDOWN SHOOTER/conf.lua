function love.conf(t)
    t.window.title = "TOPDOWN SHOOTER"

    t.window.width = 854
    t.window.height = 480
    --t.window.borderless = true

end